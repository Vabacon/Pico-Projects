This directory contains examples that demonstrate basic and token authentication.
