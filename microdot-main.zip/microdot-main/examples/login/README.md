This directory contains examples that demonstrate user logins.
