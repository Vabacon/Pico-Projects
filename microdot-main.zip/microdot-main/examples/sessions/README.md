This directory contains examples that take advantage of user sessions.
